#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

out vec4 fragColor;

void main() {
    if (abs(FogEnvironmentalEnd - 8191.25) < 0.0625) {
        vec4 sky = ColorModulator;
        if (max(sky.r, max(sky.g, sky.b)) < 0.001) {
            sky = vec4(0.71764706, 0.85098039, 1.0, 1.0);
        }
        fragColor = sky;
        return;
    }
    fragColor = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
